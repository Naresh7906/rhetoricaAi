import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ThemeToggle } from "@/components/theme-toggle";
import { Building } from "lucide-react";

export function EmployeeLogin() {
  const navigate = useNavigate();

  const handleSSOLogin = () => {
    // TODO: Implement SSO authentication
    navigate("/employee/dashboard");
  };

  return (
    <div className="min-h-screen flex bg-background">
      {/* Left Section */}
      <div className="hidden lg:flex lg:w-1/2 p-8 items-center justify-center bg-gradient-to-b from-purple-50 to-white dark:from-purple-950/30 dark:to-background">
        <div className="max-w-md space-y-4">
          <h1 className="text-4xl font-bold gradient-text">Develop your</h1>
          <div className="space-y-2">
            <p className="text-4xl font-bold text-purple-600 dark:text-purple-400">Professional</p>
            <p className="text-4xl font-bold">and</p>
            <p className="text-4xl font-bold text-purple-600 dark:text-purple-400">Communication</p>
            <p className="text-4xl font-bold">expertise</p>
          </div>
          <img 
            src="/illustration.svg" 
            alt="Professional Development Illustration" 
            className="w-96 h-96 object-contain animate-float"
          />
        </div>
      </div>

      {/* Right Section */}
      <div className="flex-1 flex flex-col items-center justify-center p-8">
        <div className="absolute right-4 top-4">
          <ThemeToggle />
        </div>
        
        <Card className="w-full max-w-md">
          <CardHeader className="space-y-4 text-center">
            <Building className="w-12 h-12 mx-auto text-purple-600 dark:text-purple-400" />
            <div>
              <CardTitle className="text-2xl font-bold gradient-text">
                Rhetorica.AI
              </CardTitle>
              <p className="text-xl font-semibold mt-2">Employee Portal</p>
              <p className="text-sm text-muted-foreground mt-1">
                Sign in with your corporate credentials
              </p>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button 
              className="w-full gradient-bg hover:opacity-90 text-lg py-6"
              onClick={handleSSOLogin}
            >
              Sign in with SSO
            </Button>

            <p className="text-center text-sm text-muted-foreground">
              By continuing, you agree to our{" "}
              <a href="#" className="text-primary hover:underline">Terms of Service</a>
              {" "}and{" "}
              <a href="#" className="text-primary hover:underline">Privacy Policy</a>.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
} 