import { Routes, Route } from "react-router-dom";
import { ThemeProvider } from "./components/theme-provider";
import { HRLogin } from "./pages/hr/login";
import { HRDashboard } from "./pages/hr/dashboard";
import { EmployeeLogin } from "./pages/employee/login";
import { EmployeeDashboard } from "./pages/employee/dashboard";
import { CourseDetails } from "./pages/employee/course-details";

export default function App() {
  return (
    <ThemeProvider defaultTheme="dark" storageKey="vite-ui-theme">
      <Routes>
        {/* HR Routes */}
        <Route path="/hr/login" element={<HRLogin />} />
        <Route path="/hr/dashboard" element={<HRDashboard />} />
        
        {/* Employee Routes */}
        <Route path="/employee/login" element={<EmployeeLogin />} />
        <Route path="/employee/dashboard" element={<EmployeeDashboard />} />
        <Route path="/employee/courses/:courseId" element={<CourseDetails />} />
        
        {/* Default redirect */}
        <Route path="*" element={<EmployeeLogin />} />
      </Routes>
    </ThemeProvider>
  );
}
